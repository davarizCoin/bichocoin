import { type Language, languageLabels } from "@/data/translations";

interface Props {
  current: Language;
  onChange: (lang: Language) => void;
}

const languages: Language[] = ["pt", "en", "es", "fr", "ja", "ru"];

const LanguageSelector = ({ current, onChange }: Props) => {
  return (
    <div className="flex items-center justify-center gap-1 py-4">
      {languages.map((lang) => (
        <button
          key={lang}
          onClick={() => onChange(lang)}
          className={`px-2 py-1 rounded text-xs font-bold transition-all ${
            current === lang
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground hover:text-foreground"
          }`}
        >
          {languageLabels[lang]}
        </button>
      ))}
    </div>
  );
};

export default LanguageSelector;

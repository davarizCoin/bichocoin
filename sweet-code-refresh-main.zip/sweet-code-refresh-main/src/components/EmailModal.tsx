import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface Props {
  open: boolean;
  onSubmit: (email: string) => void;
}

const EmailModal = ({ open, onSubmit }: Props) => {
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.includes("@") && email.includes(".")) {
      onSubmit(email);
    }
  };

  return (
    <Dialog open={open}>
      <DialogContent className="max-w-sm [&>button]:hidden">
        <DialogHeader>
          <DialogTitle className="text-center font-display text-2xl">🎲 BichoCoin<span className="text-xs">.com</span></DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <p className="text-sm text-muted-foreground text-center">
            Informe seu e-mail para receber o seu prêmio
          </p>
          <Input
            type="email"
            placeholder="seu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button type="submit" className="w-full font-display text-lg" size="lg">
            Entrar
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EmailModal;

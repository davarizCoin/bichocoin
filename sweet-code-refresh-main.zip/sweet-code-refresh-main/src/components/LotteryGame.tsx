import { useState, useEffect } from "react";
import { type LotteryGameConfig } from "@/data/games";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import QRCodeModal from "@/components/QRCodeModal";
import CountdownTimer, { gameSchedules, useBettingStatus } from "@/components/CountdownTimer";

const MONTH_NAMES = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

interface Props {
  game: LotteryGameConfig;
  email: string;
  onBack: () => void;
}

const LotteryGame = ({ game, email, onBack }: Props) => {
  const [selected, setSelected] = useState<number[]>([]);
  const [bonus, setBonus] = useState<number | null>(null);
  const [bonusMulti, setBonusMulti] = useState<number[]>([]);
  const [showQR, setShowQR] = useState(false);
  const schedule = gameSchedules[game.id];
  const { bettingOpen } = useBettingStatus(schedule);

  const bonusCount = game.bonusCount || 1;
  const useMultiBonus = bonusCount > 1;

  const toggleNumber = (n: number) => {
    if (!bettingOpen) return;
    setSelected((prev) =>
      prev.includes(n)
        ? prev.filter((x) => x !== n)
        : prev.length < game.numbersToSelect
        ? [...prev, n]
        : prev
    );
  };

  const toggleBonusMulti = (n: number) => {
    setBonusMulti((prev) =>
      prev.includes(n)
        ? prev.filter((x) => x !== n)
        : prev.length < bonusCount
        ? [...prev, n]
        : prev
    );
  };

  const isBonusReady = !game.hasBonus || (useMultiBonus ? bonusMulti.length === bonusCount : bonus !== null);
  const isReady = selected.length === game.numbersToSelect && isBonusReady;

  // Auto-open QR when all selections are made
  useEffect(() => {
    if (isReady && !showQR && bettingOpen) {
      setShowQR(true);
    }
  }, [isReady]);

  const buildMemo = () => {
    const nums = [...selected].sort((a, b) => a - b).join("-");
    if (useMultiBonus) {
      const bonusPart = bonusMulti.length > 0 ? `-T${[...bonusMulti].sort((a, b) => a - b).join("-")}` : "";
      return `${game.prefix}-${nums}${bonusPart}-${email}`;
    }
    const bonusPart = bonus ? `-E${bonus}` : "";
    return `${game.prefix}-${nums}${bonusPart}-${email}`;
  };

  const handleClose = () => {
    setShowQR(false);
    setSelected([]);
    setBonus(null);
    setBonusMulti([]);
  };

  const numbers = Array.from({ length: game.maxNumber }, (_, i) => i + 1);
  const bonusNumbers = game.bonusMax
    ? Array.from({ length: game.bonusMax }, (_, i) => i + 1)
    : [];

  return (
    <div className="space-y-5">
      <Button variant="ghost" size="sm" onClick={onBack} className="text-muted-foreground">
        <ArrowLeft className="mr-1 h-4 w-4" /> Voltar
      </Button>

      <div className="text-center">
        <span className="text-3xl">{game.emoji}</span>
        <h2 className="text-xl font-display font-bold text-foreground mt-1">{game.name}</h2>
        <p className="text-xs text-muted-foreground">
          Escolha {game.numbersToSelect} números (1-{game.maxNumber})
        </p>
      </div>

      {schedule && <CountdownTimer schedule={schedule} />}

      <div className="grid grid-cols-10 gap-1.5">
        {numbers.map((n) => (
          <button
            key={n}
            onClick={() => toggleNumber(n)}
            disabled={!bettingOpen}
            className={`aspect-square rounded-md text-sm font-bold transition-all ${
              selected.includes(n)
                ? "bg-primary text-primary-foreground scale-110 shadow-sm"
                : "bg-card border border-border text-foreground hover:border-gold"
            } disabled:opacity-40 disabled:cursor-not-allowed`}
          >
            {n.toString().padStart(2, "0")}
          </button>
        ))}
      </div>

      <p className="text-center text-xs text-muted-foreground">
        {selected.length}/{game.numbersToSelect} selecionados
      </p>

      {/* Single bonus (Powerball, Mega Millions, Dia de Sorte month) */}
      {game.hasBonus && !useMultiBonus && selected.length === game.numbersToSelect && (
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground font-medium text-center">
            Escolha o {game.bonusLabel} (1-{game.bonusMax}):
          </p>
          {game.bonusIsMonth ? (
            <div className="grid grid-cols-3 gap-2">
              {bonusNumbers.map((n) => (
                <button
                  key={n}
                  onClick={() => setBonus(n)}
                  className={`py-3 rounded-lg text-sm font-bold transition-all ${
                    bonus === n
                      ? "bg-gold text-gold-foreground scale-105 shadow-gold"
                      : "bg-card border border-border text-foreground hover:border-gold"
                  }`}
                >
                  {MONTH_NAMES[n - 1]}
                </button>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-10 gap-1.5">
              {bonusNumbers.map((n) => (
                <button
                  key={n}
                  onClick={() => setBonus(n)}
                  className={`aspect-square rounded-md text-sm font-bold transition-all ${
                    bonus === n
                      ? "bg-gold text-gold-foreground scale-110 shadow-gold"
                      : "bg-card border border-border text-foreground hover:border-gold"
                  }`}
                >
                  {n.toString().padStart(2, "0")}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Multi bonus (+Milionária trevos) */}
      {game.hasBonus && useMultiBonus && selected.length === game.numbersToSelect && (
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground font-medium text-center">
            Escolha {bonusCount} {game.bonusLabel}s (1-{game.bonusMax}):
          </p>
          <div className="grid grid-cols-6 gap-2">
            {bonusNumbers.map((n) => (
              <button
                key={n}
                onClick={() => toggleBonusMulti(n)}
                className={`aspect-square rounded-lg text-lg font-bold transition-all ${
                  bonusMulti.includes(n)
                    ? "bg-gold text-gold-foreground scale-110 shadow-gold"
                    : "bg-card border border-border text-foreground hover:border-gold"
                }`}
              >
                🍀{n}
              </button>
            ))}
          </div>
          <p className="text-center text-xs text-muted-foreground">
            {bonusMulti.length}/{bonusCount} trevos
          </p>
        </div>
      )}

      {showQR && (
        <QRCodeModal
          open={showQR}
          onClose={handleClose}
          memoText={buildMemo()}
          amount={game.betAmount}
          gameId={game.id}
        />
      )}
    </div>
  );
};

export default LotteryGame;

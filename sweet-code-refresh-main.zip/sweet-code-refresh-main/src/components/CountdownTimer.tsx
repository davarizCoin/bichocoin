import { useState, useEffect } from "react";

export interface DrawSchedule {
  drawDays: number[];  // 0=Sun, 1=Mon, etc.
  drawHour: number;    // Hour in Brasília time (UTC-3)
  drawMinute?: number;
}

export const gameSchedules: Record<string, DrawSchedule> = {
  quina:           { drawDays: [1, 2, 3, 4, 5, 6], drawHour: 21 },
  "mega-sena":     { drawDays: [2, 4, 6],           drawHour: 21 },
  "dia-de-sorte":  { drawDays: [2, 4, 6],           drawHour: 21 },
  "mais-milionaria": { drawDays: [3, 6],             drawHour: 21 },
  "mega-millions": { drawDays: [3, 6],               drawHour: 0 },
  powerball:       { drawDays: [2, 4, 0],            drawHour: 0, drawMinute: 59 },
};

export const useBettingStatus = (schedule: DrawSchedule) => {
  const [bettingOpen, setBettingOpen] = useState(true);

  useEffect(() => {
    const check = () => {
      const now = getBrasiliaTime();
      const day = now.getDay();
      const mins = now.getHours() * 60 + now.getMinutes();
      const drawMins = schedule.drawHour * 60 + (schedule.drawMinute || 0);
      const closeMins = drawMins - 30;
      const reopenMins = drawMins + 120;

      if (schedule.drawDays.includes(day)) {
        if (mins >= closeMins && mins < reopenMins) {
          setBettingOpen(false);
          return;
        }
      }
      setBettingOpen(true);
    };
    check();
    const interval = setInterval(check, 10000);
    return () => clearInterval(interval);
  }, [schedule]);

  return { bettingOpen };
};

function getBrasiliaTime(): Date {
  const now = new Date();
  // Convert to Brasília (UTC-3)
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  return new Date(utc - 3 * 3600000);
}

interface Props {
  schedule: DrawSchedule;
}

const CountdownTimer = ({ schedule }: Props) => {
  const [timeLeft, setTimeLeft] = useState("");
  const [closed, setClosed] = useState(false);

  useEffect(() => {
    const tick = () => {
      const now = getBrasiliaTime();
      const day = now.getDay();
      const mins = now.getHours() * 60 + now.getMinutes();
      const drawMins = schedule.drawHour * 60 + (schedule.drawMinute || 0);
      const closeMins = drawMins - 30;
      const reopenMins = drawMins + 120;

      // Check if betting is closed right now
      if (schedule.drawDays.includes(day) && mins >= closeMins && mins < reopenMins) {
        setClosed(true);
        setTimeLeft("");
        return;
      }
      setClosed(false);

      // Find next draw
      const next = getNextDraw(now, schedule);
      const diff = next.getTime() - now.getTime();
      if (diff <= 0) { setTimeLeft("Sorteio agora!"); return; }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setTimeLeft(`${d > 0 ? d + "d " : ""}${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`);
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [schedule]);

  if (closed) {
    return (
      <div className="text-center bg-card border border-destructive rounded-xl p-4">
        <p className="text-lg font-display font-bold text-destructive animate-pulse">
          🚫 APOSTAS ENCERRADAS
        </p>
      </div>
    );
  }

  return (
    <div className="text-center bg-card border border-border rounded-xl p-4">
      <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Próximo sorteio em</p>
      <p className="text-2xl font-display font-bold text-gold tracking-wider">{timeLeft}</p>
    </div>
  );
};

function getNextDraw(now: Date, schedule: DrawSchedule): Date {
  for (let i = 0; i < 8; i++) {
    const candidate = new Date(now);
    candidate.setDate(now.getDate() + i);
    candidate.setHours(schedule.drawHour, schedule.drawMinute || 0, 0, 0);
    if (schedule.drawDays.includes(candidate.getDay()) && candidate > now) {
      return candidate;
    }
  }
  const fallback = new Date(now);
  fallback.setDate(now.getDate() + 7);
  fallback.setHours(schedule.drawHour, schedule.drawMinute || 0, 0, 0);
  return fallback;
}

export default CountdownTimer;

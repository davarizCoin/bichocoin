import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { bichoQRCodes, lotteryQRCodes } from "@/data/qrCodes";

interface Props {
  open: boolean;
  onClose: () => void;
  memoText: string;
  amount: number;
  gameId?: string;
  bichoCategory?: string;
}

const bichoMultipliers: Record<string, { label: string; multiplier: number }> = {
  grupo: { label: "Grupo", multiplier: 18 },
  dezena: { label: "Dezena", multiplier: 60 },
  centena: { label: "Centena", multiplier: 600 },
  milhar: { label: "Milhar", multiplier: 6000 },
};

const QRCodeModal = ({ open, onClose, memoText, amount, gameId = "bicho", bichoCategory }: Props) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedBet, setCopiedBet] = useState(false);

  const qrConfig = gameId === "bicho"
    ? bichoQRCodes[amount]
    : lotteryQRCodes[gameId];

  const bichoInfo = gameId === "bicho" && bichoCategory ? bichoMultipliers[bichoCategory] : null;
  const potentialWin = bichoInfo ? amount * bichoInfo.multiplier : 0;

  const handleCopyCode = async () => {
    if (qrConfig) {
      await navigator.clipboard.writeText(qrConfig.copyCode);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const handleCopyBet = async () => {
    await navigator.clipboard.writeText(memoText);
    setCopiedBet(true);
    setTimeout(() => setCopiedBet(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-center font-display">Bitcoin Lightning Network</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center gap-4 py-4">
          {/* QR Code Image */}
          {qrConfig ? (
            <img
              src={qrConfig.image}
              alt="QR Code PIX"
              className="w-48 h-48 rounded-xl border-2 border-border"
            />
          ) : (
            <div className="w-48 h-48 bg-muted rounded-xl flex items-center justify-center border-2 border-dashed border-border">
              <div className="text-center text-muted-foreground">
                <span className="text-4xl block mb-2">📱</span>
                <span className="text-xs">QR Code PIX</span>
              </div>
            </div>
          )}

          {/* Blue button - Copy PIX Code */}
          <Button
            onClick={handleCopyCode}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-display"
          >
            {copiedCode ? (
              <><Check className="mr-2 h-4 w-4" /> Copiado!</>
            ) : (
              <><Copy className="mr-2 h-4 w-4" /> Copiar QR Code</>
            )}
          </Button>

          {/* Memo */}
          <div className="bg-card border border-border rounded-lg p-3 w-full text-center space-y-1">
            <p className="text-xs text-muted-foreground uppercase tracking-widest">Memo</p>
            <p className="font-mono text-sm font-bold text-foreground break-all">{memoText}</p>
          </div>

          <p className="text-2xl font-display font-bold text-gold">R$ {amount.toFixed(2)}</p>

          {bichoInfo && (
            <p className="text-sm font-display font-bold text-red-500 animate-pulse">
              "{bichoInfo.label} {bichoInfo.multiplier}x" — acertou, ganhou R${potentialWin.toFixed(2)}!
            </p>
          )}

          {/* Gold button - Copy Bet Info */}
          <Button
            onClick={handleCopyBet}
            className="w-full bg-gold hover:bg-gold/90 text-gold-foreground font-display"
          >
            {copiedBet ? (
              <><Check className="mr-2 h-4 w-4" /> Copiado!</>
            ) : (
              <><Copy className="mr-2 h-4 w-4" /> Copiar Memo</>
            )}
          </Button>



        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QRCodeModal;

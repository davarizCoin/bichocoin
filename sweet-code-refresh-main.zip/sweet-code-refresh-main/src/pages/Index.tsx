import { useState } from "react";
import { categories, type CategoryType, type Animal } from "@/data/animals";
import { lotteryGames, type LotteryGameConfig } from "@/data/games";
import CountdownTimer, { gameSchedules, useBettingStatus } from "@/components/CountdownTimer";
import AnimalGrid from "@/components/AnimalGrid";
import BetAmountSelector from "@/components/BetAmountSelector";
import QRCodeModal from "@/components/QRCodeModal";
import LotteryGame from "@/components/LotteryGame";
import Header from "@/components/Header";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import EmailModal from "@/components/EmailModal";

type ActiveGame = null | "bicho" | string;

const BichoGame = ({ email, onBack, initialCategory = "grupo" }: { email: string; onBack: () => void; initialCategory?: CategoryType }) => {
  const [category, setCategory] = useState<CategoryType>(initialCategory);
  const [line, setLine] = useState<number | null>(null);
  const [selectedAnimal, setSelectedAnimal] = useState<Animal | null>(null);
  const [selectedDezena, setSelectedDezena] = useState<string | null>(null);
  const [numberInput, setNumberInput] = useState("");
  const [betAmount, setBetAmount] = useState<number | null>(null);
  const [showQR, setShowQR] = useState(false);

  const { bettingOpen } = useBettingStatus({ drawDays: [3, 6], drawHour: 19 });
  const categoryPrefix = categories.find(c => c.key === category)!.prefix;

  const buildMemo = () => {
    if (category === "grupo") {
      if (!selectedAnimal || !line) return "";
      const animalNum = selectedAnimal.group.toString().padStart(2, "0");
      return `${categoryPrefix}${line}-${animalNum}-${email}`;
    } else if (category === "dezena") {
      if (!selectedDezena || !line) return "";
      return `${categoryPrefix}${line}-${selectedDezena}-${email}`;
    } else {
      if (!numberInput || !line) return "";
      return `${categoryPrefix}${line}-${numberInput}-${email}`;
    }
  };

  const handleBetAmount = (amount: number) => {
    setBetAmount(amount);
    setShowQR(true);
  };

  const handleCloseQR = () => {
    setShowQR(false);
    setBetAmount(null);
    setSelectedAnimal(null);
    setSelectedDezena(null);
    setNumberInput("");
    setLine(null);
  };

  const isNumberValid = category === "centena" ? numberInput.length === 3 : numberInput.length === 4;
  const isDezenaSelected = category === "dezena" && selectedDezena !== null;

  const reset = () => {
    setSelectedAnimal(null);
    setSelectedDezena(null);
    setNumberInput("");
    setLine(null);
  };

  const handleSelectDezena = (animal: Animal, dezena: string) => {
    setSelectedAnimal(animal);
    setSelectedDezena(dezena);
  };

  const showBetSelector = line && (
    (category === "grupo" && selectedAnimal) ||
    (category === "dezena" && isDezenaSelected) ||
    ((category === "centena" || category === "milhar") && isNumberValid)
  );

  return (
    <div className="space-y-5">
      <Button variant="ghost" size="sm" onClick={onBack} className="text-muted-foreground">
        <ArrowLeft className="mr-1 h-4 w-4" /> Voltar
      </Button>

      <div className="text-center">
        <span className="text-3xl">🎲</span>
        <h2 className="text-xl font-display font-bold text-foreground mt-1">Jogo do Bicho</h2>
      </div>

      <CountdownTimer schedule={{ drawDays: [3, 6], drawHour: 19 }} />

      {/* Category Tabs */}
      <div className="grid grid-cols-4 gap-1 bg-muted rounded-lg p-1">
        {categories.map((cat) => (
          <button
            key={cat.key}
            onClick={() => { setCategory(cat.key); reset(); }}
            className={`py-2 rounded-md text-sm font-display font-semibold tracking-wide transition-all ${
              category === cat.key
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Line Selection */}
      {!line && (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground font-medium text-center">
            Escolha a linha (1ª a 5ª):
          </p>
          <div className="grid grid-cols-5 gap-2">
            {[1, 2, 3, 4, 5].map((l) => (
              <button
                key={l}
                onClick={() => setLine(l)}
                disabled={!bettingOpen}
                className="py-3 rounded-lg bg-card border-2 border-border hover:border-gold hover:shadow-gold transition-all font-display text-lg font-bold text-foreground hover:text-gold disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {l}ª
              </button>
            ))}
          </div>
        </div>
      )}

      {line && !showBetSelector && (
        <Button variant="ghost" size="sm" onClick={reset} className="text-muted-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" /> Voltar
        </Button>
      )}

      {/* Grupo mode */}
      {line && category === "grupo" && !selectedAnimal && (
        <AnimalGrid line={line} onSelect={setSelectedAnimal} />
      )}

      {/* Dezena mode - list with dezenas */}
      {line && category === "dezena" && !isDezenaSelected && (
        <AnimalGrid line={line} onSelect={() => {}} showDezenas onSelectDezena={handleSelectDezena} />
      )}

      {/* Centena / Milhar */}
      {line && (category === "centena" || category === "milhar") && !isNumberValid && (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground font-medium text-center">
            Linha {line} — Digite {category === "centena" ? "3" : "4"} números:
          </p>
          <div className="flex gap-2 max-w-xs mx-auto">
            <Input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={category === "centena" ? 3 : 4}
              value={numberInput}
              onChange={(e) => setNumberInput(e.target.value.replace(/\D/g, ""))}
              placeholder={category === "centena" ? "000" : "0000"}
              className="text-center text-2xl font-mono font-bold tracking-widest"
            />
          </div>
        </div>
      )}

      {/* Bet summary + amount selector */}
      {showBetSelector && !showQR && (
        <div className="space-y-4">
          <div className="bg-card border border-gold/30 rounded-xl p-4 text-center space-y-1">
            <p className="text-xs text-muted-foreground uppercase tracking-widest">Sua aposta</p>
            {selectedAnimal && <p className="text-3xl">{selectedAnimal.emoji}</p>}
            <p className="font-display text-lg font-bold text-foreground">{buildMemo() || "..."}</p>
            <Button variant="ghost" size="sm" onClick={reset} className="text-muted-foreground text-xs mt-1">
              <ArrowLeft className="mr-1 h-3 w-3" /> Alterar
            </Button>
          </div>
          <BetAmountSelector onSelect={handleBetAmount} />
        </div>
      )}

      {showQR && betAmount && (
        <QRCodeModal open={showQR} onClose={handleCloseQR} memoText={buildMemo()} amount={betAmount} gameId="bicho" bichoCategory={category} />
      )}
    </div>
  );
};

const Index = () => {
  const [email, setEmail] = useState<string | null>(null);
  const [dark, setDark] = useState(false);
  const [activeGame, setActiveGame] = useState<ActiveGame>(null);

  const toggleDark = () => {
    setDark((d) => {
      document.documentElement.classList.toggle("dark", !d);
      return !d;
    });
  };

  const handleChangeEmail = () => setEmail(null);

  const activeLottery = lotteryGames.find((g) => g.id === activeGame);

  return (
    <div className="min-h-screen bg-background transition-colors">
      <EmailModal open={!email} onSubmit={setEmail} />
      <Header dark={dark} onToggleDark={toggleDark} email={email} onChangeEmail={handleChangeEmail} />

      <main className="container py-6 space-y-6 max-w-lg mx-auto">
        {activeGame === null && (
          <>
            {/* Jogo do Bicho */}
            <section className="space-y-3">
              <h3 className="text-xs text-muted-foreground uppercase tracking-widest text-center font-medium">
                🎲 Jogo do Bicho
              </h3>
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: "Grupo", key: "grupo" as CategoryType, color: "bg-emerald-600 hover:bg-emerald-700", emoji: "🦁" },
                  { label: "Dezena", key: "dezena" as CategoryType, color: "bg-sky-600 hover:bg-sky-700", emoji: "🔢" },
                  { label: "Centena", key: "centena" as CategoryType, color: "bg-orange-600 hover:bg-orange-700", emoji: "💯" },
                  { label: "Milhar", key: "milhar" as CategoryType, color: "bg-rose-600 hover:bg-rose-700", emoji: "🎰" },
                ].map((cat) => (
                  <button
                    key={cat.label}
                    onClick={() => setActiveGame(`bicho-${cat.key}`)}
                    className={`${cat.color} text-white rounded-xl p-4 flex flex-col items-center gap-2 transition-all shadow-md hover:scale-105`}
                  >
                    <span className="text-2xl">{cat.emoji}</span>
                    <span className="font-display font-bold text-sm tracking-wide">{cat.label}</span>
                  </button>
                ))}
              </div>
            </section>

            <div className="border-t border-border" />

            {/* Loterias Brasileiras */}
            <section className="space-y-3">
              <h3 className="text-xs text-muted-foreground uppercase tracking-widest text-center font-medium">
                🍀 Loterias Brasileiras
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {lotteryGames.filter((g) => ["quina", "mega-sena", "dia-de-sorte", "mais-milionaria"].includes(g.id)).map((game) => (
                  <button
                    key={game.id}
                    onClick={() => setActiveGame(game.id)}
                    className={`${game.color} rounded-xl p-5 flex flex-col items-center gap-2 transition-all shadow-md hover:scale-105`}
                  >
                    <span className="text-3xl">{game.emoji}</span>
                    <span className="font-display font-bold text-sm tracking-wide">{game.name}</span>
                    <span className="text-xs opacity-80">R${game.betAmount}</span>
                  </button>
                ))}
              </div>
            </section>

            <div className="border-t border-border" />

            {/* Power Ball & Mega Millions */}
            <section className="space-y-3">
              <h3 className="text-xs text-muted-foreground uppercase tracking-widest text-center font-medium">
                🇺🇸 Loterias Americanas
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {lotteryGames.filter((g) => g.id === "powerball" || g.id === "mega-millions").map((game) => (
                  <button
                    key={game.id}
                    onClick={() => setActiveGame(game.id)}
                    className={`${game.color} rounded-xl p-5 flex flex-col items-center gap-2 transition-all shadow-md hover:scale-105`}
                  >
                    <span className="text-3xl">{game.emoji}</span>
                    <span className="font-display font-bold text-sm tracking-wide">{game.name}</span>
                    <span className="text-xs opacity-80">R${game.betAmount}</span>
                  </button>
                ))}
              </div>
            </section>
          </>
        )}

        {activeGame?.startsWith("bicho") && email && (
          <BichoGame
            email={email}
            onBack={() => setActiveGame(null)}
            initialCategory={(activeGame.split("-")[1] as CategoryType) || "grupo"}
          />
        )}

        {activeLottery && email && (
          <LotteryGame game={activeLottery} email={email} onBack={() => setActiveGame(null)} />
        )}

        {email && (
          <>
            <p className="text-center text-xs text-muted-foreground">
              Apostando como: <span className="font-medium text-foreground">{email}</span>
            </p>
            <div className="flex items-center justify-center gap-4 py-4">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-2xl hover:scale-110 transition-transform">📘</a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-2xl hover:scale-110 transition-transform">📷</a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-2xl hover:scale-110 transition-transform">🐦</a>
              <a href="https://telegram.org" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-2xl hover:scale-110 transition-transform">✈️</a>
              <a href="mailto:contato@bichocoin.com" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full bg-muted flex items-center justify-center text-2xl hover:scale-110 transition-transform">📧</a>
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default Index;

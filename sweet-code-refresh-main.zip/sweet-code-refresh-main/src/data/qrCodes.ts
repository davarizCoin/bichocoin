// =====================================================
// QR CODE CONFIGURATION - EDITE AQUI PARA TROCAR QR CODES
// =====================================================
// Para trocar um QR code:
// 1. Coloque a nova imagem na pasta public/qrcodes/
// 2. Atualize o campo "image" abaixo com o novo caminho
// 3. Atualize o campo "copyCode" com o novo código PIX

export interface QRCodeConfig {
  image: string;    // caminho da imagem em public/
  copyCode: string; // código PIX para copiar
}

// ---- JOGO DO BICHO (5 valores) ----
export const bichoQRCodes: Record<number, QRCodeConfig> = {
  1: {
    image: "/qrcodes/bicho-1.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_R1",
  },
  2: {
    image: "/qrcodes/bicho-2.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_R2",
  },
  5: {
    image: "/qrcodes/bicho-5.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_R5",
  },
  10: {
    image: "/qrcodes/bicho-10.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_R10",
  },
  20: {
    image: "/qrcodes/bicho-20.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_R20",
  },
};

// ---- LOTERIAS (1 QR por jogo) ----
export const lotteryQRCodes: Record<string, QRCodeConfig> = {
  quina: {
    image: "/qrcodes/quina.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_QUINA",
  },
  "mega-sena": {
    image: "/qrcodes/mega-sena.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_MEGA_SENA",
  },
  "dia-de-sorte": {
    image: "/qrcodes/dia-de-sorte.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_DIA_DE_SORTE",
  },
  "mais-milionaria": {
    image: "/qrcodes/mais-milionaria.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_MAIS_MILIONARIA",
  },
  "mega-millions": {
    image: "/qrcodes/mega-millions.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_MEGA_MILLIONS",
  },
  powerball: {
    image: "/qrcodes/powerball.png",
    copyCode: "COLE_AQUI_O_CODIGO_PIX_POWERBALL",
  },
};

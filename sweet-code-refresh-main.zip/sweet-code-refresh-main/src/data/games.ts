export interface LotteryGameConfig {
  id: string;
  name: string;
  emoji: string;
  color: string;
  prefix: string;
  betAmount: number;
  numbersToSelect: number;
  maxNumber: number;
  hasBonus?: boolean;
  bonusMax?: number;
  bonusLabel?: string;
  bonusCount?: number; // how many bonus numbers to pick (default 1)
  bonusIsMonth?: boolean; // for Dia de Sorte month selection
}

export const lotteryGames: LotteryGameConfig[] = [
  {
    id: "quina",
    name: "Quina",
    emoji: "🍀",
    color: "bg-purple-600 hover:bg-purple-700 text-white",
    prefix: "Q",
    betAmount: 1,
    numbersToSelect: 5,
    maxNumber: 80,
  },
  {
    id: "mega-sena",
    name: "Mega Sena",
    emoji: "🎯",
    color: "bg-green-700 hover:bg-green-800 text-white",
    prefix: "S",
    betAmount: 2,
    numbersToSelect: 6,
    maxNumber: 60,
  },
  {
    id: "dia-de-sorte",
    name: "Dia de Sorte",
    emoji: "☀️",
    color: "bg-amber-600 hover:bg-amber-700 text-white",
    prefix: "DS",
    betAmount: 3,
    numbersToSelect: 7,
    maxNumber: 31,
    hasBonus: true,
    bonusMax: 12,
    bonusLabel: "Mês da Sorte",
    bonusIsMonth: true,
  },
  {
    id: "mais-milionaria",
    name: "+Milionária",
    emoji: "🍀💰",
    color: "bg-teal-700 hover:bg-teal-800 text-white",
    prefix: "M+",
    betAmount: 6,
    numbersToSelect: 6,
    maxNumber: 50,
    hasBonus: true,
    bonusMax: 6,
    bonusLabel: "Trevo da Sorte",
    bonusCount: 2,
  },
  {
    id: "powerball",
    name: "Powerball",
    emoji: "⚡",
    color: "bg-red-600 hover:bg-red-700 text-white",
    prefix: "P",
    betAmount: 5,
    numbersToSelect: 5,
    maxNumber: 69,
    hasBonus: true,
    bonusMax: 26,
    bonusLabel: "Powerball",
  },
  {
    id: "mega-millions",
    name: "Mega Millions",
    emoji: "💰",
    color: "bg-blue-700 hover:bg-blue-800 text-white",
    prefix: "MM",
    betAmount: 10,
    numbersToSelect: 5,
    maxNumber: 70,
    hasBonus: true,
    bonusMax: 25,
    bonusLabel: "Mega Ball",
  },
];

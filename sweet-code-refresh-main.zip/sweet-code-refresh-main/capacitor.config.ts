import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.bcf3605db22a4c3e898fa0fdf98d14e4',
  appName: 'BichoCoin',
  webDir: 'dist',
  server: {
    url: 'https://bcf3605d-b22a-4c3e-898f-a0fdf98d14e4.lovableproject.com?forceHideBadge=true',
    cleartext: true,
  },
};

export default config;
